#include <stdio.h>

int main(void) {
    
    int potenciaLamp, quantidadeLamp;
    float altura, largura, comprimento, volume;
    char tipoSala;

    //pede o usuario as informacoes

    printf(
    "\n+--------------+--------------------------------+"
    "\n| Tipo da sala | Pot�ncia necess�ria (watts/m3) |"
    "\n+--------------+--------------------------------+"
    "\n| A            |                            8.5 |"
    "\n| B            |                           11.3 |"
    "\n| C            |                           15.0 |"
    "\n| D            |                           18.8 |"
    "\n| E            |                           22.0 |"
    "\n+--------------+--------------------------------+"
    "\nTipo da sala:");
    scanf("%c", &tipoSala);

    printf("\nInforme a potencia da lampada(em watts): ");
    scanf("%i", &potenciaLamp);

    printf("\nAltura, largura e comprimento em metros, respectivamente(Ex.:4,5,6): ");
    scanf("%f,%f,%f", &altura, &largura, &comprimento);



    //o volume � dado:
    volume = (altura*largura*comprimento)/1000;


    //em cada tipo de sala, sera calculado a quantidade individual de lampadas
    switch (tipoSala)
    {
    case 'A': {
        //a partir daqui, essa forma calcular� enfim a quantidade de lampadas
        quantidadeLamp = ((volume*potenciaLamp)/8.5);
        printf("Sao necessarias %i lampadas", quantidadeLamp);
    }
        break;

    case 'B': {
        quantidadeLamp = ((volume*potenciaLamp)/11.3);
        printf("Sao necessarias %i lampadas", quantidadeLamp);
    }
        break;

    case 'C': {
        quantidadeLamp = ((volume*potenciaLamp)/15);
        printf("Sao necessarias %i lampadas", quantidadeLamp);
    }
        break;

    case 'D': {
        quantidadeLamp = ((volume*potenciaLamp)/18.8);
        printf("Sao necessarias %i lampadas", quantidadeLamp);
    }
        break;

    case 'E': {
        quantidadeLamp = ((volume*potenciaLamp)/22);
        printf("Sao necessarias %i lampadas", quantidadeLamp);
    }
        break;
    
    default: printf("ERRO - Opcao invalida");//Caso seja dado uma op��o inexistente
        break;
    }

    return 0;
}

/*Tendo em vista que uma maquina n�o consegue, logo de cara, entender o que foi apresentado,o
compilador entra e faz essa tradu��o de linguagem alto n�vel(linguagem escrita pelo programador),
para enfim um processador e sistema operacional consigam entender.*/
