/*(Quest�o 1 - 2,5 pontos) Fa�a um programa em C que leia 4 valores inteiros e apresente o maior deles, 
o menor deles e a m�dia deles. Explique na forma de coment�rios, e com suas palavras, 
o que � o processo de compila��o de um c�digo fonte de um programa de computador e como voc� 
realizou a compila��o e teste do seu c�digo.
*/

#include <stdio.h>

int main(void) {

    int numero, numMaior, numMenor; //para execucao do condigo, foi usado o auxiliar numero
    int i;

    float media;
 
    printf("Informe um inteiro:");
    scanf("%i",&numero);
   
   //aplicacao da auxiliar
    numMenor = numero;
    numMaior = numero;

    media = numero;
    
    //ja que queremos 4 inteiros, o loop sera executado 4 vezes para os inteiros
    for(i = 1; i<4; i++) {
   
    printf("Informe um inteiro:");
    scanf("%i",&numero);

    media = media + numero;//faz a soma de todos inteiros
 
    if(numero > numMaior) {
        numMaior = numero;
    } 

    else if(numero < numMenor) {
        numMenor = numero;
    }
    }

    //enfim, insere os valores requisitados
    printf("Maior= %i, Menor = %i", numMaior, numMenor);
    printf("\nA media dos inteiros = %.1f",media/4);


    return 0;
}

/*Sucintamente, o processo de compila��o � quando o computador transforma o c�digo de um programa
para a linguagem de maquina, para que o computador entenda o codigo fonte do programa escrito
em uma linguagem de alto nivel por um programador

Para a compila��o do apresentado codigo, foi utilizado um terminal(cmd nesse caso). A execucao
pode ser feita de forma mais simples por meio da propria IDE(VS Code) e o programa CodeRunner
que facilita esse processo. Para compilar manualmente, foi inserido os seguintes c�digos no terminal:
1� gcc ./questao1.c  (processo de compila��o)
2� a.exe   (execu��o)

*/
