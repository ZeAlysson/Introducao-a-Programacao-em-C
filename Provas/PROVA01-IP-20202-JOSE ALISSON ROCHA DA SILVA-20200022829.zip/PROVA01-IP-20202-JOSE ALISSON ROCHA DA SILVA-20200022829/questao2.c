#include <stdio.h>
#include <stdlib.h>

int main(void) {

    float salarioCliente, emprestimo, prestacao;
    
    printf("Insira o salario: ");
    scanf("%f", &salarioCliente);

    printf("\nValor do emprestimo: ");
    scanf("%f", &emprestimo);

    printf("\nValor da prestacao: ");
    scanf("%f", &prestacao);


    //Quando a prestacao for maior que 15% do salario do cliente, nao sera concebido emprestimo e o programa encerrara
    if (prestacao>(0.15*salarioCliente)) {
        printf("Emprestimo nao concedido");
        exit(0);
    }

    else {
        //caso o emprestimo seja maior que 10% do salario do cliente, nao sera concebido emprestimo e o programa encerrara
        if (emprestimo>(10*salarioCliente)) {
            printf("Emprestimo nao concebido");
            exit(0);
        }

        else {
            //se a prestacaoo for menor que 10% do emprestimo, nao sera concebido e o programa encerrara
            if (prestacao<(0.01*emprestimo)) {
                printf("Emprestimo nao concebido");
                exit(0);
            }
            //caso nenhuma das condicaos se apliquem ao cliente, seu emprestimo sera concebido 
            else {
                printf("Emprestimo concebido");
            }          
        }
    }

    //se o emprestimo for concebido, o programa prossegue e exibi em qual perfil de cobran�a 
    //de juros que o cliente esta
   
   /*cliente vip se valor da presta��o < 5% do salario do cliente ou o valor do 
   emprestimo < que 5x o sal�rio do cliente, sera dado Perfil Vip*/
    if ((prestacao<(0.05*salarioCliente)) || (emprestimo<(5*salarioCliente)) ) {
        printf("\nPerfil VIP");
    }

    /*Perfil Normarl, se o valor da presta��o for maior que 5% do sal�rio do cliente e menor que
     10% do sal�rio ou o valor do empr�stimo for entre 5x e 8x o sal�rio do cliente*/
    else {
        if ( (prestacao>(0.05*salarioCliente)) && (prestacao<(0.1*salarioCliente)) || 
           (emprestimo>=(5*salarioCliente) && (emprestimo<=(8*salarioCliente))) ) 
        {
               printf("\nPerfil Normal");
        }

        //caso as condicoes nao se apliquem, sera dado como Perfil de Risco
        else {
            printf("\nPerfil de Risco");
        }
        
    }

    return 0;
}
