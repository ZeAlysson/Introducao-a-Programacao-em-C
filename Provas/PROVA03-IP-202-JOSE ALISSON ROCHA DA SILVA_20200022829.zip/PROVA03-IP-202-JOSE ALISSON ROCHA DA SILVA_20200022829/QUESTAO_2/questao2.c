#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
2) (2,5 + 1 pontos) Fa�a um programa em C que contenha estruturas para
armazenar novos tipos de dados de acordo com as informa��es abaixo:

	- Hor�rio: hora, minutos e segundos, vari�veis inteiras;
	- Data: dia, m�s e ano, vari�veis inteiras;
	- Compromisso: composto por uma string de 50 caracteres,
			Hor�rio e Data;

Declare as estruturas e fa�a o programa solicitar informa��es ao usu�rio
para cadastrar 3 inst�ncias (3 compromissos), armazenando-os em um array;
exiba o conte�do dos tr�s compromissos. Finalmente, leia dois inteiros M e A e
mostre todos os compromissos do m�s M do ano A.

(+1 ponto): fa�a o programa perguntar quantos compromissos o usu�rio quer
cadastrar e reserve o espa�o de mem�ria para o array dinamicamente, solicitando
os dados para a quantidade de compromissos definida, e exibindo todos eles em
seguida.
*/

typedef struct
{
    int hora, minutos, segundos;
} sHorario;

typedef struct
{
    int dia, mes, ano;
} sData;

typedef struct
{
   char compromisso[50];
   sHorario horario;
   sData data; 
} sCompromissos;


int main(void)
{
    int i, qtd_compromissos;
    int M, A;

    sCompromissos *array_instancias;//ptr do tipo struct sCompromissos que engloba as demais structs

    printf("\nQuantos compromissos deseja agendar?\n");
    scanf("%d", &qtd_compromissos);//ler o quantos compromissos serao agendados

    //alocacao de memoria para o array dinamicamente
    array_instancias = (sCompromissos*)malloc(qtd_compromissos*sizeof(sCompromissos));

    
    if(array_instancias == NULL)//verificar se a memoria foi alocada com sucesso
    {
        printf("malloc error\n");
        exit(0);
    }

    //o loop rodara de acordo com a quantidade de compromissos que o usuario inseriu
    for (i = 0; i < qtd_compromissos; i++)
    {   
        printf("\n************ CADASTRANDO COMPROMISSO[%d] **************\n", i);
        
        //ler e armazena o horario no vetor contendo as structs
        printf("\nInsira HORA, MINUTOS e SEGUNDOS, respectivamente: ");
        scanf("%d%d%d", &array_instancias[i].horario.hora,
                        &array_instancias[i].horario.minutos,
                        &array_instancias[i].horario.segundos);
        
        //ler e armazena a data no vetor contendo as structs
        printf("Insira DIA, MES e ANO, respectivamente: ");
        scanf("%d%d%d", &array_instancias[i].data.dia,
                        &array_instancias[i].data.mes,
                        &array_instancias[i].data.ano);

        //ler e armazena a descricao no vetor contendo as structs
        printf("Informa um descricao para o compromisso: ");
        scanf("%s", &array_instancias[i].compromisso);

        printf("\nCompromisso[%d] agendado com sucesso!\n", i);//confirmacao de cadastro
        printf("\n******************************************************\n");
    }
    
    //o loop exibe os dados inseridos pelo usuario de acordo com a quantidade de compromissos
    for (i = 0; i < qtd_compromissos; i++)
    {   
        printf("\n\n------- Exibindo informacoes do COMPROMISSO[%d] -------\n", i);

        //exibe o horario
        printf("\nHorario: %d HORAS, %d MINUTOS %d SEGUNDOS\n", array_instancias[i].horario.hora,
                                                                array_instancias[i].horario.minutos,
                                                                array_instancias[i].horario.segundos);

        //exibe a data
        printf("\nData: %d/%d/%d\n", array_instancias[i].data.dia,
                                     array_instancias[i].data.mes,
                                     array_instancias[i].data.ano);

        //exibe a descricao
        printf("\nDescricao: %s\n", array_instancias[i].compromisso);
        printf("\n------------------------------------------------------\n", i);
    }

    printf("\n\nConsultando compromissos...\n");
    printf("\nInsira o mes(int) e ano(int), respectivamente, que deseja consultar: ");
    scanf("%d%d", &M, &A);//ler o mes e ano que deseja consultar

    printf("\n\n -------- Compromissos do mes[%d] do ano[%d] -------\n", M, A);

    ////exibe as informacoes conforme a quantidade de compromissos inseridos
    for (i = 0; i < qtd_compromissos; i++)
    {
        //enquanto mes e ano inseridos anteriormente condizem, e o mes pertencer ao mesmo ano
        //do compromisso inserido, a funcao imprime os comprimissos do mes com mesmo ano
        if (M == array_instancias[i].data.mes && A == array_instancias[i].data.ano)
        {
            //exibe as informacoes do mesmo mes, do mesmo ano
            printf("\nHorario: %d HORAS, %d MINUTOS %d SEGUNDOS\n", array_instancias[i].horario.hora,
                                                                    array_instancias[i].horario.minutos,
                                                                    array_instancias[i].horario.segundos);

            printf("\nData: %d/%d/%d\n", array_instancias[i].data.dia,
                                         array_instancias[i].data.mes,
                                         array_instancias[i].data.ano);

            printf("\nDescricao: %s\n", array_instancias[i].compromisso);
            printf("\n------------------------------------------------------\n", i);
        } 
    }
    
    return 0;
}
