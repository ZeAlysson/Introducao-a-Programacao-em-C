#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
1) (2,5 pontos) Fa�a um programa em C que contenha uma fun��o que receba:
	- uma string (char*)
	- o tamanho da string

Fa�a esta fun��o retornar/preencher um array de valores inteiros, onde
cada posi��o representa a quantidade de vezes que cada letra do alfabeto
aparece na string passada como argumento. Fa�a o programa chamar a fun��o
com algumas strings de exemplo dentro da fun��o main().

Ex. para a string "AaaABBcZz", ter�amos os seguintes valores para o
array (com 26 posi��es):
	int contador[26];
...
	contador[0] = 4 //4 ocorrencias da letra A
	contador[1] = 2 //2 ocorrencias da letra B
	contador[2] = 1 //1 ocorrencia da letra C
... (todas as posi��es intermedi�rias com o valor 0 (zero).
	contador[25] = 2 //2 ocorrencias da letra Z
*/

#define MAX_CARACTERES 255 //valor da quantidade de caracteres da tabela ASCII

quantidade_letras(char* string, int tamanho_string)
{   
    int string_aux[tamanho_string];
    int vetor_inteiros[MAX_CARACTERES];
    int i, j;

    //zerando os valores para poder incrementar o vetor posteriormente
    for (i = 0; i < MAX_CARACTERES; i++)
    {
        vetor_inteiros[i] = 0; 
    }
    
    //chama a string e define seus caracteres como inteiro armazenando-a numa variavel int
    for (i = 0; i < tamanho_string; i++)
    {
        string_aux[i] = string[i];
    }
    
    /*se houver valores de caracteres em MAIUSCULO, de acordo com os valores da tabela ASCII  os tranforma em minusculo de acordo com
    os valores da tabela ASCII*/
    for (i = 0; i < tamanho_string; i++)
    {
        if (string_aux[i] > 64 && string_aux[i] < 91)//se caractere tiver valor maisculo da tabela,
        {
           string_aux[i] += 32;//...soma com os valores da tabela para realizar conversao 
        }
    }

    //define quantas vezes o caractere foi repetido
    for (i = 0; i < tamanho_string; i++)
    {                       
        vetor_inteiros[string_aux[i]]++;//conta e guarda o valor repetido
    }

    //por fim, imprimi os caracteres que foram repetidos e quantas vezes foram repetidos
    for (i = 0; i < MAX_CARACTERES; i++)
    { 
        //determina somente os caracteres do alfabeto da tabela ASCII... 
        if (i > 96 && i < 123)
        {
            //...ande os imprime junto com quantas vezes foram repetidos
            printf("\ncaractere [%c] tem %d ocorrencias\n", i, vetor_inteiros[i]);
        }                
    }
}

int main(void)
{
    char* palavra1 = "AaaABBcZz";//palavra de teste
    char* palavra2 = "josealisson";//palavra de teste
    int tamanho1, tamanho2;
    char resposta;

    tamanho1 = strlen(palavra1);//guarda tamanho da palavra1
    tamanho2 = strlen(palavra2);//guarda tamanho da palavra2


    //enquanto o usuario nao encerrar o programa, o mesmo contianuara pedindo que insira uma resposta
    while (resposta != 'c')
    {   
        printf("==================================================================\n");
        printf("\nO que deseja?\n\n(a)Testar palavra 1\n(b)Testar palavra 2\n(c)Encerrar programa\n");
        printf("\nEscolha uma opcao: ");
        scanf("%c", &resposta);
        printf("\n==================================================================\n");

        fflush(stdin);

        //conforme a resposta do usuario, testa os seguintes casos:
        switch (resposta)
        {
        case 'A':
        case 'a': printf("Testanto '%s'...\n", palavra1);
                  quantidade_letras(palavra1, tamanho1);//invoca funcao testando palavra 1
            break;

        case 'B':
        case 'b': printf("Testanto '%s'...\n", palavra2);
                  quantidade_letras(palavra2, tamanho2);//invoca funcao testando palavra 2
            break;

        case 'C':
        case 'c': printf("\nPrograma encerrado com sucesso\n");//mensagem de encerrramento do programa
            break;
        
        default: printf("\nOpcao invalidade! Tente novamente\n");
            break;
        }
    }
    return 0;
}
