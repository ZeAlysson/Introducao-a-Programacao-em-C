#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
3) (2,5 + 1 pontos) Fa�a um programa em C que tenha um array com dados de 5 
livros. Os dados dever�o estar em uma estrutura contendo: t�tulo (string com 
30 caracteres), autor (string com 15 caracteres) e ano (int). Implemente tr�s
fun��es que realizem a busca de livros por t�tulo, por autor e por ano. Pe�a
ao usu�rio os dados de 5 livros e depois exiba um menu onde pode-se fazer
cada uma das buscas implementadas em fun��es, al�m da op��o de fechar o 
programa. 

(+ 1 ponto): fa�a o programa perguntar quantos livros ser�o armazenados no
array e reserve o espa�o de mem�ria dinamicamente, solicitando os dados de 
acordo com a quantidade estabelecida. 
*/

typedef struct
{
    char titulo[30];
    char autor[15];
    int ano;
} tLivro;

buscar_por_titulo (tLivro* livro, int num_livros)
{   
}

buscar_por_nomeAutor (tLivro* livro, int num_livros)
{
}

buscar_por_ano (tLivro* livro, int num_livros)
{
    int i;
    int ano_livro;

    printf ("\nInforme o ano do livro que deseja buscar: ");
    scanf("%d", &ano_livro);//ler o ano inserido pelo usuario


    for (i = 0; i < num_livros; i++)
    {
        //se por acaso o ano inserido estiver cadastrado, exibe as informacoes presentes no ano
        if (ano_livro == livro[i].ano);
        {   
            printf("\nTitulo: %s\n", livro[i].titulo);
            printf("\nAutor: %s\n", livro[i].autor);
        }  
    }
}

int main(void)
{
    int i, qtd_livros;
    char opcao;

    tLivro *armazenamento;//variavel do tipo tLivro que contem a quantidade de itens
    
    printf("Quantos livros deseja registar? ");
    scanf("%d", &qtd_livros);//ler qnts livros serao registrados

    armazenamento = (tLivro*)malloc(qtd_livros*sizeof(tLivro));
  
    //o loop rodara de acordo com a qtd de livros inseridos
    //ademais, ira armazenar as informacoes na estrutura
    for (i = 0; i < qtd_livros; i++)
    {
        printf("\nInsira os dados do livro[%d]:\n", i);

        printf("\nTitulo do livro: ");
        scanf("%s", &armazenamento[i].titulo);

        fflush(stdin);

        printf("\nAutor do livro: ");
        scanf("%s", &armazenamento[i].autor);

        fflush(stdin);

        printf("\nAno do livro: ");
        scanf("%d", &armazenamento[i].ano);

        fflush(stdin);
    }

    fflush(stdin);//limpa buffer do teclado
    
    //enquando o usuario nao encerrar, o programa continuara pedindo uma opcao valida
    while ((opcao != 'd') && (opcao != 'D'))
    {
        fflush(stdin);
        
        printf (
        "\n==================================================================\n"
        "\n\ta) Buscar livro por titulo\n"
        "\tb) Buscar livro por autor\n"
        "\tc) Buscar livro pelo ano\n"
        "\td) Sair\n"
        );

        printf("\t\nInforme a opcao desejada: ");
        scanf("%c", &opcao);//ler opcao desejada
        printf("\n==================================================================\n");

        fflush(stdin);
        
        //executa as funcoes de acordo com o caractere inserido
        switch (opcao)
        {
            /*em cada funcao invocada, entra um vetor(armazenamento) com a estrutura de 'tLivro'
            na qual vai ser preencida/exibida*/
            case 'a':
            case 'A': {
                
            } break;

            case 'b':
            case 'B': {
                
            } break;

            case 'c':
            case 'C': {
                buscar_por_ano(armazenamento, qtd_livros);
            } break;

            case 'd':
            case 'D': {
                printf("\nxxxxxxxxxxxxxxxxx ENCERRADO xxxxxxxxxxxxxxxxx\n");
                exit(0);
            }
        }
    }
    return 0;
}
