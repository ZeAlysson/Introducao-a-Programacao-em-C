A IDE E EXTENSÕES UTILIZADAS SÃO AS MESMAS QUE AS DAS AULAS DE INTRODUÇÃO A PROGRAMAÇÃO 
(VS Code, C/C++, C/C++ Compile Run, Code Runner).


Usando o Code Runner, basta clicar no icone de *PLAY* ou Ctrl + Alt + N 
que compilará e executará automaticamente. Depois, basta inserir o que se pede no terminal.

