/*
5) (3 pontos) Fa�a um programa em C que solicite ao usu�rio tr�s palavras 
(strings) e depois solicite um caractere ao usu�rio para perguntar se ele quer
exibir as strings: 
	a) em ordem alfab�tica
	b) em ordem crescente de quantidade de caracteres
	c) com seus caracteres em ordem reversa
*/

#include <stdio.h>
#include <string.h>

int main(void)
{
    char string1[10];
    char string2[10];
    char string3[10];
    char caractere;

    printf("Insira palavra 1: ");
    scanf("%s", string1);

    printf("Insira palavra 2: ");
    scanf("%s", string2);

    printf("Insira palavra 3: ");
    scanf("%s", string3);

    printf("a) em ordem alfab�tica\n"
            "b) em ordem crescente de quantidade de caracteres\n"
            "c) com seus caracteres em ordem reversa\n");

    printf("\nInsira um caractere: ");
    scanf("%s", &caractere);

    switch (caractere) {

        //jogo de if's das tres varia��es possiveis na ordem alfab�tica
        case 'a':   if (strcmp(string1,string2) == -1) 
                    {
                        if (strcmp(string1, string3) == -1) 
                        {
                            printf("%s\n", string1);
                            if (strcmp(string2, string3) == -1) 
                            {
                                printf("%s\n%s\n", string2, string3);
                            } else {
                                printf("%s\n%s\n", string3, string2);
                              }
                        } else {
                            printf("%s\n%s\n%s\n", string3, string1, string2);
                        }
                    } else 
                    {
                        if (strcmp(string2, string3) == -1) 
                        {
                            printf("%s\n", string2);
                            if (strcmp(string1, string3) == -1) 
                            {
                                printf("%s\n%s\n", string1, string3);
                            } else {
                                printf("%s\n%s\n", string3, string1);
                            }
                        } else {
                            printf("%s\n%s\n%s\n", string3, string2, string1);
                        }
                    }
        break;

        case 'b': {//sem tempo :(

        }

        default:
        break;

    }


    return 0;
}
