/*
4) (2 pontos) Fa�a um programa em C que solicite ao usu�rio uma palavra 
(string) e depois altere a palavra para que todas as vogais mai�sculas sejam
substitu�das por vogais min�sculas e vice-versa. Exiba a string resultante e
quantas vogais foram alteradas. Explique nos coment�rios todas as etapas.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char palavra[20];
    int i, cont_vogais=0;

    printf("\nInsira uma palavra: ");
    gets(palavra);

    //Sucintamente, o loop repetir� cada caractere da string 
    for (i = 0; i <= strlen(palavra); i++)
    {
        /*Cada um dos caracteres passa pela analise na qual determina se o caractere � uma vogal,
        e se essa vogal est� em uppercase ou lowercase*/
        switch(palavra[i]) 
        {    
            /*Se a vogal se encaixa nos quesitos lowercase/minuscula, a mesma � convertida para
            uppercase/maiuscula. Para isso, foi usado o comando toupper() da biblioteca ctype.h, onde
            a mesma cont�m fun��es para manipula��o de caracteres*/
            case 'a': 
            case 'e':  
            case 'i':  
            case 'o':  
            case 'u': palavra[i] = toupper(palavra[i]); ++cont_vogais;//adiciona +1 valor na variavel quando e se alguma vogal for convertida
            break;

            /*Se a vogal se encaixa nos quesitos uppercase/maiuscula, a mesma � convertida para
            lowercase/minuscula. Para isso, foi usado o comaando tolower() da biblioteca ctype.h*/
            case 'A':  
            case 'E':  
            case 'I':  
            case 'O':  
            case 'U': palavra[i] = tolower(palavra[i]); ++cont_vogais;//adiciona +1 valor na variavel quando e se alguma vogal for convertida
            break;
        }

        printf("%c", palavra[i]);//imprime a sequencia de caracteres
    }

    printf("\n%d vogais foram alteradas\n", cont_vogais);//imprime a quantidade de vogais alteradas
    
    
    return 0;
}
