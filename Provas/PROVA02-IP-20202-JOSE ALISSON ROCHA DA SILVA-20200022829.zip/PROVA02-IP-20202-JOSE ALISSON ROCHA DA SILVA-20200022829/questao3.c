/*
3) (1 ponto) Fa�a um programa em C que calcule e armazene em um array 
bidimensional os valores das tabuadas de 1 a 10. Depois, solicite do usu�rio
um valor inteiro entre 1 e 10 (repita a solicita��o enquanto o usu�rio n�o
inserir corretamente) e exiba a tabuada do n�mero correspondente, a partir
dos valores constantes no array bidimensional.
*/

#include <stdio.h>

int main(void)
{   
    int tabuada [10][10]; 
    int inteiro, i, j;

    //loop criado, caso o numero inserido n�o estiver de acordo com as condi��es, continuar� 
    //pedindo para o usuario inserir um numero v�lido
    do
    {
        printf("Insira um inteiro(1 a 10): ");
        scanf("%d", &inteiro);

    } while (inteiro < 1 || inteiro > 10);


    for (i = 1; i <= 10; i++)//enumera as linhas da tabuada na i-�sima posi��o, variando de 1 a 10
    {
        //efetua o calculo do numero solicitado com as i-�simas posi��es
        for (j = 0; j <= 10; j++)
        {
            tabuada[i][inteiro] = i*inteiro;
        }

        printf("tabuada[%d][%d] = %d\n", i, inteiro, tabuada[i][inteiro]);
    }
            
    return 0;
}
