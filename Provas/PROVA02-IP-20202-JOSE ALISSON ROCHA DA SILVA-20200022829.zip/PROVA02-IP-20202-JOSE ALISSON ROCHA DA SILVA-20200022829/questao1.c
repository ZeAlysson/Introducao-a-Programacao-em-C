/*
1) (2 pontos) Um determinado material radioativo perde metade de sua massa
a cada 50 segundos. Fa�a um programa em C que pergunte a massa inicial (float),
em gramas, e calcule o tempo necess�rio para que essa massa do material se 
torne menor que 0,5 grama. O programa em C deve apresentar a massa inicial, a 
massa final e o tempo em segundos. Explique nos coment�rios como funciona
a estrutura de repeti��o utilizada.
*/

#include <stdio.h>

int main(void)
{
    float massa_inicial, tempo_nescessario_seg, calculo_massa;

    printf("\nInsira a massa inicial: ");
    scanf("%f", &massa_inicial);

    calculo_massa = massa_inicial;//variavel auxiliar para massa inicial

    /*A seguir, a massa � reduzida pela metade at� que a mesma se torne menor que 0,5 gramas. Ademais, 
    � cada loop, � atribu�do o valor de 50 segundos na variavel tempo_nescessario_seg chegando 
    no tempo em que a massa se torna em 0,5 grama*/
    tempo_nescessario_seg = 0;
    while (calculo_massa >= 0.5)  
    {
        calculo_massa *= 0.5;//redu��o da massa pela metade por loop
        tempo_nescessario_seg+= 50;//soma do tempo total de segundos
    }

    //imprime os resultados finais
    printf("Massa inicial = %.2f gramas\n", massa_inicial);
    printf("Massa final = %.2f gramas\n", calculo_massa);
    printf("Tempo = %.0f segundos\n", tempo_nescessario_seg);

    return 0;
}
