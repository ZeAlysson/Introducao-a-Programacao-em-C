/*
2) (1 ponto) Fa�a um programa em C que pe�a um n�mero inteiro inicial ao 
usu�rio, um valor inteiro de raz�o e calcule os 10 primeiros termos de uma
P.G. (Progress�o Geom�trica), armazenando-os em um array de tamanho 10. 
Depois exiba os itens do array na ordem inversa e diga quantos dos valores
armazenados s�o pares. Explique nos coment�rios como funcionam os arrays.
*/

#include <stdio.h>
#include <math.h>

int main(void)
{
    /*Quando temos um valor n�o t�o pequeno de variaveis torna-se dif�cil gerenci�-las. 
    Sendo assim usando os arrays, ideia � representar muitas inst�ncias em uma vari�vel.*/

    int inteiroInicial, razao, vetor[10];
    int i, contPares=0;

    printf("\nInsira um numero inicial: ");
    scanf("%d", &inteiroInicial);
    
    printf("Insira a razao: ");
    scanf("%d", &razao);

    //Para calcular uma P.G, temos: a1 * r^(n-1)

    vetor[0] = inteiroInicial;//define o primeiro termo como sendo o numero inserido pelo usuario


    /*De acordo com a propriedade, calcula a P.G dos 10 primeiros termos e armazena o resultado
    em um dos dez arrays a cada loop */
    for (i = 1; i <= 10; i++)
    {   
        //a1 * r^(n-1)
        vetor[i] = vetor[0] * (pow(razao, i));

        /*Sendo divisel por 2 com resto 0, ou seja, quando resultados das 10 posi��es forem
        par, +1 valor � adicionado na variavel contadora de pares*/
        if(vetor[i] % 2 == 0) {
            ++contPares;
        }
    }

    //imprime os valores armazenados em cada um dos dez arrays
    for(i = 0; i < 10; i++) 
    {
        printf("%d\n", vetor[i]);
    }

    printf("\nOrdem inversa da P.G:\n");

    //imprime os valores armazenados nos arrays na ordem inversa
    for (i = 9; i >= 0; i--)
    {
         printf("\n%d", vetor[i]);
    }

    //imprime quantos valores sao pares
    printf("\n\n%d valores sao pares\n", contPares);
    
    /**/
    
    

    return 0;
}
